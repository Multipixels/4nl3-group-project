# Starting Kit

Please refer to the competition's Codabench's "Get Started" page for details on using these files.