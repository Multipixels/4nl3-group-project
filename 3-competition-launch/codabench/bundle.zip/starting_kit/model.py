import numpy as np
import pandas as pd

class Model:
    def __init__(self):
        pass
    
    # Train the model
    def fit(self, X, y):
        pass

    # Predict labels.
    def predict(self, X):
        pass