import numpy as np
import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

class Model:
    def __init__(self):
        lr_model = LogisticRegression()
        vectorizer = TfidfVectorizer()

    def vectorize_train_data(self, X):
        X_vect = self.vectorizer.fit_transform(X)
        return X_vect

    def vectorize_test_data(self, X):
        X_vect = self.vectorizer.transform(X)
        return X_vect

    # Train the model
    def fit(self, X, y):
        X_vect = self.vectorize_data(X)
        self.lr_model.fit(X_vect, y)        

    # Predict labels.
    def predict(self, X):
        X_vect = self.vectorize_test_data(X)
        y_pred = self.lr_model.predict(X_vect)
        return y_pred